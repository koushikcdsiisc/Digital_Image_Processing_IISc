# -*- coding: utf-8 -*-
"""
Created on Mon Nov 19 22:27:28 2018

@author: raghav
"""

import cv2
import numpy as np
def Canny_edge(I,th_L,th_H):

    (m,n)= I.shape
    img= np.float64(I)
    
    der_i= np.float64([[-1],[0],[1]])
    der_j= np.float64([[-1,0,1]])
    
    der_j = np.float64([[-1, 0, 1],[-1, 0, 1],[-1, 0, 1]])
     
    # construct the Prewit y-axis kernel
    der_i = np.float64([[-1, -1, -1],[0, 0, 0],[1, 1, 1]])
    
    g_i= cv2.filter2D(img, -1,der_i)
    g_j= cv2.filter2D(img, -1,der_j)
    
    M= np.sqrt(g_i**2+g_j**2)
    
    direction= np.degrees(np.arctan(g_i/(g_j+0.000001)))# 0.0000001 is to avoid NAN condition
    # (devide by zero ) and g_j is intergers so adding small quantity will not affect somthing 
    
    # canny maxima suppression 
    G_n= np.zeros((m,n),np.float64)
    edge= np.zeros((m,n),np.uint8)
    gap =0
    
    
    for i in range(0,m-1):
        for j in range (0,n-1):
            if (direction[i,j]<=22.5) and (direction[i,j]>=-22.5):#vertical edge go horizontal
                
                if j>0:
                    if (M[i,j]+gap<M[i,j-1]) or  (M[i,j]+gap<M[i,j+1]):
                        G_n[i,j]=0
                    else:
                        G_n[i,j]=M[i,j]
                elif (M[i,j]+gap<M[i,j+1]):
                    G_n[i,j]=0
                else:G_n[i,j]=M[i,j]
                    
            if (direction[i,j]>22.5) and (direction[i,j]<=67.5):# -45 degree
                if i>0 and j>0:
                    if (M[i,j]+gap<M[i+1,j+1]) or  (M[i,j]+gap<M[i-1,j-1]):
                        G_n[i,j]=0
                    else:
                        G_n[i,j]=M[i,j]
                elif(M[i,j]+gap<M[i+1,j+1]):
                    G_n[i,j]=0
                else:
                    G_n[i,j]=M[i,j]
                    
                    
            if (direction[i,j]<-22.5) and (direction[i,j]>=-67.5):#+45 degree
                
                if i>0 and j>0:
                    if (M[i,j]+gap<M[i-1,j+1]) or  (M[i,j]+gap<M[i+1,j-1]):
                        G_n[i,j]=0
                    else:
                        G_n[i,j]=M[i,j]
                
            if ((direction[i,j]>67.5) and (direction[i,j]<=90.0)) or ((direction[i,j]<-67.5) and (direction[i,j]>=-90.0)):#horizontal
                
                if i>0:
                    if (M[i,j]+gap<M[i-1,j]) or  (M[i,j]+gap<M[i+1,j]):
                        G_n[i,j]=0
                    else:
                        G_n[i,j]=M[i,j]
                elif (M[i,j]+gap<M[i+1,j]):
                    G_n[i,j]=0
                else:
                    G_n[i,j]=M[i,j]
                
            if i>1 and j>1:
                if G_n[i-1,j-1]>=th_H:
                    temp= G_n[i-2:i+1,j-2:j+1]
                    edge[i-2:i+1,j-2:j+1] = np.float64([[255 if x > th_L else 0 for x in array] for array in temp])
        #            edge[i-1,j-1]= G_n[i-1,j-1]
                else:
                    edge[i-1,j-1]=0
            else:
                if G_n[i,j]>=th_H:
                    edge[i,j]=255
                if i>0 and j>0:
                    temp= G_n[i-1:i+1,j-1:j+1]
                    edge[i-1:i+1,j-1:j+1] = np.float64([[255 if x > th_L else 0 for x in array] for array in temp])
    
                
                
            


            
    return edge     
                

            



