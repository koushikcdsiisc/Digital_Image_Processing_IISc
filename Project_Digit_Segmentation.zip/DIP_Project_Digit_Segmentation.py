
"""
Created on Sat Oct 20 19:13:31 2018

@author: raghav, koushik
"""

import cv2
import numpy as np
from matplotlib import pyplot as plt
from homomorphic import homo_filt
from Hough_Transform import Hough
from Canny_edge import Canny_edge

#Read the card Image
I = cv2.imread('TEST_image.png',0);

# Apply Homomorphic filtering
I2= homo_filt(I)

#Threshold the Image
I_th,I_bin_rot = cv2.threshold(I2,0,255,cv2.THRESH_OTSU);
I_bin2= np.uint8(I_bin_rot)

#Hough Transform to detect the most dominating edge to rotate the Image
pair= Hough(I_bin_rot)
rows = I_bin2.shape[0]
cols = I_bin2.shape[1]
img_center = (cols / 2, rows / 2)
M = cv2.getRotationMatrix2D(img_center, pair[0][1] , 1)
I_bin = cv2.warpAffine(I_bin2, M, (cols, rows), borderValue=(255))

#Crop the sides of the input credit or debit card 
(m,n)=I_bin.shape
thr=30
for i in range(0,m):
    if np.sum(I_bin[i,:]==0)>thr:
        x1=i
        break
for i in range(m-1,0,-1):
    if np.sum(I_bin[i,:]==0)>thr:
        x2=i
        break
for i in range(0,n):
    if np.sum(I_bin[:,i]==0)>thr:
        y1=i
        break
for i in range(n-1,0,-1):
    if np.sum(I_bin[:,i]==0)>thr:
        y2=i
        break
I_bin2= np.uint8(I_bin[x1:x2, y1:y2]);

#Check the aspect ratio of the card and rotate if orientataion is wrong
(m,n)= I_bin2.shape;
I_bin3= np.copy(I_bin2)
if m>n:
    rows = I_bin3.shape[0]
    cols = I_bin3.shape[1]
    img_center = (cols / 2, rows / 2)
    M = cv2.getRotationMatrix2D(img_center, pair[0][1] , 1)
    I_bin3 = cv2.warpAffine(I_bin2, M, (cols, rows), borderValue=(255))

#Canny Edge Detection for calculating the amount of Image Content in upper and lower Half
I_bin4= Canny_edge(I_bin3,20,50)
(m,n)= I_bin3.shape;

#Check the aspect ratio of the card and rotate if orientataion is wrong
mid_m= int(m/2)
if np.sum(I_bin4[0:mid_m,:]/255)>np.sum(I_bin4[mid_m:m,:]/255):
    rows = I_bin3.shape[0]
    cols = I_bin3.shape[1]
    img_center = (cols / 2, rows / 2)
    M = cv2.getRotationMatrix2D(img_center, 180 , 1)
    I_bin = cv2.warpAffine(I_bin3, M, (cols, rows), borderValue=(255))
else:
    I_bin = np.copy(I_bin3)


#Interpolation to a standard common size to set the threshold values
I_bi=cv2.resize(I_bin,(439,279),interpolation= cv2.INTER_LINEAR)
(m,n)= I_bi.shape;
I_bi= np.copy(I_bi[20:m-20,20:n-20])

#Segment out the different sections of the whole card
(m,n)= I_bi.shape;
imag_list= [];
count= 0
for i in range(0,m):
    if (np.sum(I_bi[i,:])/255> n/30)&(count==0):
        count=1
        x= i
    if (np.sum(I_bi[i,:])/255< n/30)&(count==1):
        count= 0
        y= i
        imag_list.append(I_bi[x:y+1,:])
       
number_ele= len(imag_list)
ele_count = np.zeros(number_ele);        


#To detect the section with 16 digits
black_max=[]
for i in range(0,number_ele):
    I_sec = imag_list[i];
    (h,w) = I_sec.shape
    maxi_b=0
    for j in range(10,h-10):
        count=0
        for k in range(0,w):
            if (I_sec[j][k]==0)&(count==0):
                start= k
                count=1
            if ((I_sec[j][k]==255)&(count==1)) or ((k==w-1)&(count==1)):
                count=0
                end= k
                bcount =end-start
                if(bcount>maxi_b):
                    maxi_b= bcount
                            
    if (maxi_b==0):
        maxi_b= w+1            
    black_max.append(maxi_b)

#The section with 16 digits is assumed to have a minimum count for continuous black pixels
index_dig= np.argmin(black_max)     
dig= imag_list[index_dig]
dig_orig= np.uint8(dig);
kernel = np.ones((1,3),np.uint8)

#Morphological operation to connect small gaps in the numbers and also to the noisy components
dig_tm = cv2.morphologyEx(dig, cv2.MORPH_OPEN, kernel) 
dig_m = cv2.morphologyEx(dig_tm, cv2.MORPH_CLOSE, kernel) 
kernel2 = np.ones((3,1),np.uint8)
dig_m = cv2.morphologyEx(dig_m, cv2.MORPH_CLOSE, kernel2)
dig= dig_m
c_m,c_n= dig.shape;

#To identify the connected components belonging to a same diigt
no_cc,c_im= cv2.connectedComponents(dig) 
c_img=np.uint8(c_im)
for i in range(1,no_cc):
    count=0;
    for j in range(0,c_n):
        if (i in c_img[:,j])&(count==0):
            start_cc= j
            count =1
        if ((i not in c_img[:,j]) & (count==1)):
            end_cc = j-1
            count =0
            for k in range(1,no_cc):
                if k in c_img[:,start_cc:end_cc]:
                    c_img =np.uint8([[ i if x==k else x for x in sublst] for sublst in c_img])
        
#To filter out the possibly noisy connected components with a threshold set
list_num = [];
pixel_num = c_m*c_m*2/3
th = pixel_num/10
for i in range(1,no_cc):
       for j in range(0,c_n):
            if (i in c_img[:,j])&(count==0):
                start_cc= j
                count =1
            if (i not in c_img[:,j]) & (count==1):
                end_cc = j-1
                count =0
                z= np.sum(dig_orig[:,start_cc:end_cc])/255
                if z>th:                
                    list_num.append(dig_orig[:,start_cc:end_cc])
        
#Check to separate the digits as they may get connected in the previous steps              
final_list= []
for i in range(0,len(list_num)):
    (hieght,width)=list_num[i].shape
    if (width>3*0.9*hieght):
        final_list.append(list_num[i][:,0:int(width/4)])
        final_list.append(list_num[i][:,int(width/4):int(width/2)])
        final_list.append(list_num[i][:,int(width/2):int(width*3/4)])
        final_list.append(list_num[i][:,int(width*3/4):width+1])
        
    elif (width>2*0.9*hieght):
        final_list.append(list_num[i][:,0:int(width/3)])
        final_list.append(list_num[i][:,int(width/3):int(width*2/3)])
        final_list.append(list_num[i][:,int(width*2/3):width+1])
    elif (width>hieght):
        final_list.append(list_num[i][:,0:int(width/2)])
        final_list.append(list_num[i][:,int(width/2):width+1])
    else:
        final_list.append(list_num[i])


#Final image list excluding the possible noisy components as a final check      
display_list = []
for i in range(0,len(final_list)):
    m,n = final_list[i].shape
    if np.sum(final_list[i]/255) > (m*n/10):
        display_list.append(final_list[i])
        
    
col=4
row=5
for i in range(0,len(display_list)):
    plt.subplot(row,col,i+1)
    plt.imshow(display_list[i])
plt.show()    

cv2.imshow('16_digits',dig);
cv2.imshow('Processed_Image',I_bi);


cv2.waitKey(0);
cv2.destroyAllWindows();
