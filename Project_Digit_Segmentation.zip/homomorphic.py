# -*- coding: utf-8 -*-
"""
Created on Wed Oct 10 01:14:25 2018

@author: raghav
"""

import cv2
import numpy as np
from matplotlib import pyplot as plt
def homo_filt(I):
    gamah=2.0
    gamal=0.25
    c=1
    Do=80.0
    #I= cv2.imread('TEST6.png',0)
    I=I/255;
    (m,n)= I.shape
    filt= np.zeros((m,n),np.float64)
    I2=np.log(1+I)
    f= np.fft.fft2(I2)
    fshift=np.fft.fftshift(f)
    for i in range(0,m):
        for j in range(0,n):
            x=np.square(m/2-i)+np.square(n/2-j)#distanceD
            y=np.exp(-x*c/(Do*Do))#guassian formula
            filt[i][j] =(gamah-gamal)*(1-y) +gamal
    #filt[:]=[(gamah-gamal)*(1-y) +gamal for y in filt]
    filt_f=np.multiply(fshift,filt)
    ishif_f=np.fft.ifftshift(filt_f)
    #filt_img= np.exp(ishif_f);
    filt_imag1= np.exp(np.fft.ifft2(ishif_f))
    filt_imag2 = np.abs(filt_imag1)
    filt_imag= filt_imag2;
    maxi=filt_imag.max()
    mini=filt_imag.min()
    filt_imag[:]=[(-w*255+255*mini)/(mini-maxi) for w in filt_imag]
    #filt_imag= filt_imag*255/maxi;
    return np.uint8(filt_imag)
