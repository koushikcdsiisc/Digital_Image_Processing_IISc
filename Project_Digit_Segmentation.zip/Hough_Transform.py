# -*- coding: utf-8 -*-
"""
Created on Wed Nov 14 11:38:12 2018

@author: admin
"""

import cv2
import math
import numpy as np
from matplotlib import pyplot as plt
def Hough(I):
    a,b = I.shape
    
    
    gauss = np.zeros((11,11))
    sigma = 2
    m,n = gauss.shape
    p = 5
    q = 5
    for u in range(m):
        for v in range(n):
            x = ((u - p)**2 + (v- q)**2 );
            gauss[u][v]  =  np.exp(-(x) / (2.0*sigma**2))
            
    gauss = gauss - gauss.mean(0).mean(0)
    
    Gauss_Img = cv2.filter2D(np.double(I), -1, np.double(gauss))
    Mag = np.zeros(I.shape,np.float)
    alpha = np.zeros(I.shape,np.float)
    
    h = [[-1 , 0 , 1]]
    v = [[-1],[0],[1]]
    gx = cv2.filter2D(np.double(I), -1, np.double(h))
    gy = cv2.filter2D(np.double(I), -1, np.double(v))
    magnitude = np.sqrt((gx**2)+(gy**2))
    gx[gx == 0] = 1.0
    theta = np.degrees(np.arctan(gy/(gx)))
    new_mag = np.copy(magnitude)       
    theta[theta<0] += 180
    
    for i in range(theta.shape[0]-1):
    	for j in range(theta.shape[1]-1):
    		if (theta[i,j]<=22.5 or theta[i,j]>157.5):
    			if(magnitude[i,j]<=magnitude[i-1,j]) or (magnitude[i,j]<=magnitude[i+1,j]): new_mag[i,j]=0
    		if (theta[i,j]>22.5 and theta[i,j]<=67.5):
    			if(magnitude[i,j]<=magnitude[i-1,j-1]) or (magnitude[i,j]<=magnitude[i+1,j+1]): new_mag[i,j]=0
    		if (theta[i,j]>67.5 and theta[i,j]<=112.5):
    			if(magnitude[i,j]<=magnitude[i+1,j+1]) or (magnitude[i,j]<=magnitude[i-1,j-1]): new_mag[i,j]=0
    		if (theta[i,j]>112.5 and theta[i,j]<=157.5):
    			if(magnitude[i,j]<=magnitude[i+1,j-1]) or (magnitude[i,j]<=magnitude[i-1,j+1]): new_mag[i,j]=0
    
    
    weakedges , strongedges = np.copy(new_mag), np.copy(new_mag)
    th_upp = 30
    th_low = 10
    
    
    strongedges[strongedges<th_upp] = 0
    strongedges[strongedges>th_upp] = 1
    
    #Hough Transform
    lines = np.ones((a,b))
    img = np.copy(I)
    
    diag = int(np.sqrt(np.square(a)+np.square(b)))
    hough = np.zeros((2*diag,180))
    for i in range(a):
        for j in range(b):
            if(strongedges[i,j]==1):
                for theta in range(0,180):
                    rho = int(j*np.cos((theta-90)*np.pi/180) + i*np.sin((theta-90)*np.pi/180))
                    hough[diag+rho,theta] = hough[diag+rho,theta] + 1
    
    return np.argwhere(hough.max() == hough)
    # The below for loop runs till r and theta values 
    # are in the range of the 2d array '''
    '''
    for i in range(1):                  
        pair = np.argwhere(hough.max() == hough)
        r = pair[0,0] - diag 
        theta = (pair[0,1]-90)*np.pi/180
        a = np.cos(theta)
        b = np.sin(theta) 
        x0 = a*r 
        y0 = b*r  
        x1 = int(x0 + 1000*(-b)) 
        y1 = int(y0 + 1000*(a)) 
        x2 = int(x0 - 1000*(-b)) 
        y2 = int(y0 - 1000*(a)) 
        cv2.line(lines,(x1,y1), (x2,y2), (0,0,255),2) 
        cv2.line(img,(x1,y1), (x2,y2), (0,0,255),2)
        hough[pair] = 0
    '''
    
   
    
